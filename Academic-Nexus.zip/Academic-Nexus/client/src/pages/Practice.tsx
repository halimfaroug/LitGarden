import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { Background } from "@/components/Background";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Quiz } from "@/components/Quiz";
import { Flashcard } from "@/components/Flashcard";
import { QUIZZES, FLASHCARDS } from "@/lib/mock-data";

export default function Practice() {
  const [currentCardIndex, setCurrentCardIndex] = useState(0);

  const nextCard = () => {
    setCurrentCardIndex((prev) => (prev + 1) % FLASHCARDS.length);
  };

  const prevCard = () => {
    setCurrentCardIndex((prev) => (prev - 1 + FLASHCARDS.length) % FLASHCARDS.length);
  };

  return (
    <div className="min-h-screen font-sans">
      <Background />
      <Navigation />
      
      <main className="container mx-auto px-6 pt-32 pb-20">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-serif text-primary mb-4">Active Practice</h1>
          <p className="text-xl text-muted-foreground">Test your knowledge and reinforce key concepts.</p>
        </div>

        <Tabs defaultValue="quiz" className="max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2 mb-12 bg-white/50 backdrop-blur-sm p-1 rounded-xl h-auto">
            <TabsTrigger value="quiz" className="py-3 text-lg rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">Interactive Quiz</TabsTrigger>
            <TabsTrigger value="flashcards" className="py-3 text-lg rounded-lg data-[state=active]:bg-primary data-[state=active]:text-white">Flashcards</TabsTrigger>
          </TabsList>

          <TabsContent value="quiz" className="focus-visible:ring-0">
             <Quiz 
               questions={QUIZZES} 
               onComplete={(score) => alert(`Quiz Complete! Score: ${score}/${QUIZZES.length}`)} 
             />
          </TabsContent>

          <TabsContent value="flashcards" className="focus-visible:ring-0">
            <div className="text-center mb-6 text-muted-foreground">
              Card {currentCardIndex + 1} of {FLASHCARDS.length}
            </div>
            <Flashcard 
              data={FLASHCARDS[currentCardIndex]} 
              onNext={nextCard}
              onPrev={prevCard}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
