import { Navigation } from "@/components/Navigation";
import { Background } from "@/components/Background";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, BookOpen, Brain, Layers } from "lucide-react";

export default function Home() {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 50 } }
  };

  return (
    <div className="min-h-screen font-sans text-foreground">
      <Background />
      <Navigation />
      
      <main className="container mx-auto px-6 pt-32 pb-20">
        <motion.div 
          variants={container}
          initial="hidden"
          animate="show"
          className="max-w-4xl mx-auto"
        >
          <motion.div variants={item} className="text-center mb-16">
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-semibold tracking-wide mb-6">
              ENVIRONMENTAL SCIENCE 101
            </span>
            <h1 className="text-5xl md:text-7xl font-serif text-primary mb-6 leading-tight">
              Master the Balance of Nature
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed text-balance">
              An immersive journey through ecosystems, biodiversity, and sustainability.
            </p>
            
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
               <Link href="/learn">
                <Button size="lg" className="rounded-full px-8 h-14 text-lg bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20 transition-all hover:scale-105">
                  Start Learning <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/practice">
                 <Button size="lg" variant="outline" className="rounded-full px-8 h-14 text-lg glass-card border-white/50 hover:bg-white/80 transition-all hover:scale-105">
                  Take a Quiz
                </Button>
              </Link>
            </div>
          </motion.div>

          <motion.div variants={item} className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "Structured Modules",
                desc: "Follow a clear path from core concepts to advanced case studies.",
                icon: BookOpen,
                href: "/learn",
                color: "bg-emerald-100 text-emerald-700"
              },
              {
                title: "Active Recall",
                desc: "Test your knowledge with 50+ interactive quizzes and flashcards.",
                icon: Brain,
                href: "/practice",
                color: "bg-blue-100 text-blue-700"
              },
              {
                title: "Visual Connections",
                desc: "Explore complex relationships with interactive mind maps.",
                icon: Layers,
                href: "/review",
                color: "bg-amber-100 text-amber-700"
              }
            ].map((feature, i) => (
              <Link key={i} href={feature.href}>
                <Card className="glass-panel p-8 cursor-pointer group h-full hover:-translate-y-1 transition-transform duration-300 border-none">
                  <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-6 shadow-sm`}>
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-3 group-hover:text-primary transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.desc}
                  </p>
                </Card>
              </Link>
            ))}
          </motion.div>
          
           <motion.div variants={item} className="mt-24 text-center">
             <div className="inline-block p-8 rounded-2xl glass-panel">
               <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4">Course Progress</p>
               <div className="flex gap-12 justify-center text-center">
                 <div>
                   <div className="text-4xl font-serif font-bold text-primary">0%</div>
                   <div className="text-sm text-muted-foreground mt-1">Completed</div>
                 </div>
                 <div>
                   <div className="text-4xl font-serif font-bold text-primary">0/50</div>
                   <div className="text-sm text-muted-foreground mt-1">Quizzes</div>
                 </div>
                 <div>
                   <div className="text-4xl font-serif font-bold text-primary">0/25</div>
                   <div className="text-sm text-muted-foreground mt-1">Mind Maps</div>
                 </div>
               </div>
             </div>
           </motion.div>
           
           <footer className="mt-32 text-center text-muted-foreground pb-8">
             <p className="font-serif">Developed by Halim Faroug A. Elhag</p>
             <p className="text-sm mt-1">Lecturer, UHB / UofK</p>
           </footer>
        </motion.div>
      </main>
    </div>
  );
}
