import { Navigation } from "@/components/Navigation";
import { Background } from "@/components/Background";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Learn() {
  const modules = [
    { id: 1, title: "Introduction to Ecosystems", duration: "15 min", status: "Start" },
    { id: 2, title: "Energy Flow & Trophic Levels", duration: "20 min", status: "Locked" },
    { id: 3, title: "Biogeochemical Cycles", duration: "25 min", status: "Locked" },
    { id: 4, title: "Biodiversity & Conservation", duration: "30 min", status: "Locked" },
  ];

  return (
    <div className="min-h-screen font-sans">
      <Background />
      <Navigation />
      
      <main className="container mx-auto px-6 pt-32 pb-20">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-serif text-primary mb-4">Learning Modules</h1>
            <p className="text-xl text-muted-foreground">Structured lessons designed to build your foundation.</p>
          </div>

          <div className="grid gap-6">
            {modules.map((module) => (
              <Card key={module.id} className="glass-panel p-6 flex items-center justify-between group hover:border-primary/30 transition-all">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary font-serif font-bold text-xl">
                    {module.id}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-1 group-hover:text-primary transition-colors">{module.title}</h3>
                    <span className="text-sm text-muted-foreground">{module.duration}</span>
                  </div>
                </div>
                <Button variant={module.status === 'Locked' ? 'ghost' : 'default'} disabled={module.status === 'Locked'}>
                  {module.status}
                </Button>
              </Card>
            ))}
          </div>

          <div className="mt-12 p-8 glass-panel rounded-xl">
            <h2 className="text-2xl font-serif text-primary mb-4">Current Lesson Preview</h2>
            <div className="prose prose-lg max-w-none text-muted-foreground">
              <p>
                Ecosystems are complex networks where living organisms interact with their physical environment. 
                Understanding these interactions is crucial for grasping how energy flows and nutrients cycle through our world.
                In this module, we will explore the fundamental components that make up an ecosystem...
              </p>
            </div>
            <Button variant="link" className="mt-4 px-0 text-primary text-lg">Continue Reading →</Button>
          </div>
        </div>
      </main>
    </div>
  );
}
