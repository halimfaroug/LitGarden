import { Navigation } from "@/components/Navigation";
import { Background } from "@/components/Background";
import { MindMap } from "@/components/MindMap";
import { MINDMAP_DATA } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";

export default function Review() {
  return (
    <div className="min-h-screen font-sans">
      <Background />
      <Navigation />
      
      <main className="container mx-auto px-6 pt-32 pb-20">
        <div className="max-w-4xl mx-auto">
          <div className="mb-12">
            <h1 className="text-4xl md:text-5xl font-serif text-primary mb-4">Concept Mapping</h1>
            <p className="text-xl text-muted-foreground">Visualize the connections between topics.</p>
          </div>

          <Card className="glass-panel p-8 md:p-12 min-h-[600px] border-none relative overflow-hidden">
             <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
               <span className="text-9xl font-serif font-bold text-primary">MAP</span>
             </div>
             
             <div className="relative z-10">
               <MindMap node={MINDMAP_DATA} />
             </div>
          </Card>
        </div>
      </main>
    </div>
  );
}
