import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, AlertCircle } from "lucide-react";
import { Question } from "@/lib/mock-data";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface QuizProps {
  questions: Question[];
  onComplete: (score: number) => void;
}

export function Quiz({ questions, onComplete }: QuizProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<any>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);

  const currentQuestion = questions[currentIndex];

  const handleSubmit = () => {
    let isCorrect = false;
    
    if (currentQuestion.type === 'multiple-choice' || currentQuestion.type === 'true-false') {
      isCorrect = selectedAnswer === currentQuestion.correctAnswer;
    } else if (currentQuestion.type === 'short-answer') {
      isCorrect = (selectedAnswer as string).toLowerCase().trim() === (currentQuestion.correctAnswer as string).toLowerCase().trim();
    } else if (currentQuestion.type === 'matching') {
        // Simplified matching logic for this demo
        isCorrect = JSON.stringify(selectedAnswer) === JSON.stringify(currentQuestion.correctAnswer);
    }

    if (isCorrect) {
      setScore(s => s + 1);
      setFeedback('correct');
    } else {
      setFeedback('incorrect');
    }
    
    setIsSubmitted(true);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(c => c + 1);
      setSelectedAnswer(null);
      setIsSubmitted(false);
      setFeedback(null);
    } else {
      onComplete(score + (feedback === 'correct' ? 1 : 0)); // Add last point if correct
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="mb-6 flex justify-between items-center text-sm font-medium text-muted-foreground">
        <span>Question {currentIndex + 1} of {questions.length}</span>
        <span>Score: {score}</span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
        >
          <Card className="glass-panel p-8 md:p-10 border-none">
            <h3 className="text-2xl font-serif text-primary mb-6 leading-tight">
              {currentQuestion.question}
            </h3>

            <div className="space-y-6">
              {currentQuestion.type === 'multiple-choice' && (
                <RadioGroup 
                  value={selectedAnswer} 
                  onValueChange={setSelectedAnswer}
                  disabled={isSubmitted}
                >
                  {currentQuestion.options?.map((option, i) => (
                    <div key={i} className={cn(
                      "flex items-center space-x-3 rounded-lg border p-4 transition-colors",
                      selectedAnswer === option ? "border-primary bg-primary/5" : "border-transparent hover:bg-black/5",
                      isSubmitted && option === currentQuestion.correctAnswer && "border-green-500 bg-green-50",
                      isSubmitted && selectedAnswer === option && selectedAnswer !== currentQuestion.correctAnswer && "border-red-500 bg-red-50"
                    )}>
                      <RadioGroupItem value={option} id={`opt-${i}`} />
                      <Label htmlFor={`opt-${i}`} className="flex-1 cursor-pointer text-lg font-normal">{option}</Label>
                    </div>
                  ))}
                </RadioGroup>
              )}

              {currentQuestion.type === 'true-false' && (
                <RadioGroup 
                  value={selectedAnswer} 
                  onValueChange={setSelectedAnswer}
                  disabled={isSubmitted}
                  className="flex gap-4"
                >
                  {['True', 'False'].map((option) => (
                    <div key={option} className={cn(
                      "flex-1 flex items-center justify-center rounded-lg border p-6 cursor-pointer transition-all hover:shadow-md",
                      selectedAnswer === option ? "border-primary bg-primary/5 ring-1 ring-primary" : "border-border bg-white/50",
                       isSubmitted && option === currentQuestion.correctAnswer && "border-green-500 bg-green-50",
                       isSubmitted && selectedAnswer === option && selectedAnswer !== currentQuestion.correctAnswer && "border-red-500 bg-red-50"
                    )}
                    onClick={() => !isSubmitted && setSelectedAnswer(option)}
                    >
                      <span className="text-lg font-medium">{option}</span>
                    </div>
                  ))}
                </RadioGroup>
              )}

              {currentQuestion.type === 'short-answer' && (
                <Input 
                  value={selectedAnswer || ''}
                  onChange={(e) => setSelectedAnswer(e.target.value)}
                  disabled={isSubmitted}
                  placeholder="Type your answer here..."
                  className="text-lg p-6 bg-white/50 border-border"
                />
              )}
              
              {currentQuestion.type === 'matching' && (
                  <div className="p-4 bg-muted/30 rounded-lg text-center text-muted-foreground">
                      Matching interaction simplified for prototype. (Imagine drag & drop here)
                      <Button variant="outline" className="mt-2" onClick={() => setSelectedAnswer(currentQuestion.correctAnswer)}>
                          Auto-fill Correctly (Demo)
                      </Button>
                  </div>
              )}
            </div>

            {isSubmitted && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className={cn(
                  "mt-6 p-4 rounded-lg flex items-start gap-3",
                  feedback === 'correct' ? "bg-green-100/50 text-green-900" : "bg-red-100/50 text-red-900"
                )}
              >
                {feedback === 'correct' ? <CheckCircle2 className="w-5 h-5 mt-0.5" /> : <AlertCircle className="w-5 h-5 mt-0.5" />}
                <div>
                  <p className="font-bold mb-1">{feedback === 'correct' ? 'Correct!' : 'Incorrect'}</p>
                  <p className="text-sm opacity-90">{currentQuestion.explanation}</p>
                </div>
              </motion.div>
            )}

            <div className="mt-8 flex justify-end">
              {!isSubmitted ? (
                <Button onClick={handleSubmit} disabled={!selectedAnswer} size="lg" className="px-8">
                  Check Answer
                </Button>
              ) : (
                <Button onClick={handleNext} size="lg" className="px-8">
                  {currentIndex < questions.length - 1 ? "Next Question" : "Finish Quiz"}
                </Button>
              )}
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
