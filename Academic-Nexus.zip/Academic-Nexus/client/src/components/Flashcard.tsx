import { useState } from "react";
import { motion } from "framer-motion";
import { RotateCw } from "lucide-react";
import { Flashcard as FlashcardType } from "@/lib/mock-data";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface FlashcardProps {
  data: FlashcardType;
  onNext?: () => void;
  onPrev?: () => void;
}

export function Flashcard({ data, onNext, onPrev }: FlashcardProps) {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div className="w-full max-w-xl mx-auto perspective-1000">
      <motion.div
        className="relative w-full aspect-[3/2] cursor-pointer preserve-3d"
        onClick={() => setIsFlipped(!isFlipped)}
        initial={false}
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
        style={{ transformStyle: "preserve-3d" }}
      >
        {/* Front */}
        <Card className="absolute inset-0 backface-hidden glass-panel flex flex-col items-center justify-center p-8 text-center border-none">
          <span className="text-xs uppercase tracking-widest text-muted-foreground mb-4 font-semibold">Term</span>
          <h3 className="text-4xl font-serif text-primary">{data.term}</h3>
          <p className="mt-8 text-sm text-muted-foreground flex items-center gap-2">
            <RotateCw className="w-4 h-4" /> Click to flip
          </p>
        </Card>

        {/* Back */}
        <Card 
          className="absolute inset-0 backface-hidden glass-panel flex flex-col items-center justify-center p-8 text-center border-none bg-primary/5"
          style={{ transform: "rotateY(180deg)" }}
        >
          <span className="text-xs uppercase tracking-widest text-muted-foreground mb-4 font-semibold">Definition</span>
          <p className="text-xl leading-relaxed text-foreground font-medium">{data.definition}</p>
        </Card>
      </motion.div>

      <div className="flex justify-center gap-4 mt-8">
        <Button variant="outline" onClick={onPrev} disabled={!onPrev} className="w-32 glass-card hover:bg-white/90">
          Previous
        </Button>
        <Button onClick={onNext} disabled={!onNext} className="w-32 bg-primary hover:bg-primary/90">
          Next
        </Button>
      </div>
    </div>
  );
}
