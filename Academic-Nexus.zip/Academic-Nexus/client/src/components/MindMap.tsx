import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, ChevronDown, Circle } from "lucide-react";
import { MindMapNode } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

interface MindMapProps {
  node: MindMapNode;
  depth?: number;
}

export function MindMap({ node, depth = 0 }: MindMapProps) {
  const [isOpen, setIsOpen] = useState(depth < 1); // Open root by default
  const hasChildren = node.children && node.children.length > 0;

  return (
    <div className="flex flex-col">
      <motion.div 
        layout
        className={cn(
          "flex items-center gap-3 p-3 rounded-lg transition-colors cursor-pointer group",
          depth === 0 ? "bg-primary/10 mb-4" : "hover:bg-black/5"
        )}
        onClick={() => hasChildren && setIsOpen(!isOpen)}
        style={{ marginLeft: `${depth * 24}px` }}
      >
        {hasChildren ? (
          <div className="p-1 rounded-md bg-white/50 text-primary transition-transform duration-200">
             {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        ) : (
          <Circle className="w-2 h-2 fill-primary text-primary ml-1.5" />
        )}
        
        <div className="flex-1">
          <h4 className={cn(
            "font-medium",
            depth === 0 ? "text-xl font-serif text-primary" : "text-lg text-foreground"
          )}>
            {node.label}
          </h4>
          {node.details && isOpen && (
            <motion.p 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="text-sm text-muted-foreground mt-1"
            >
              {node.details}
            </motion.p>
          )}
        </div>
      </motion.div>

      <AnimatePresence>
        {isOpen && hasChildren && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden relative"
          >
            {/* Connecting Line */}
            <div 
              className="absolute left-0 top-0 bottom-0 border-l-2 border-primary/20" 
              style={{ left: `${depth * 24 + 15}px` }} 
            />
            
            <div className="py-1">
              {node.children!.map((child) => (
                <MindMap key={child.id} node={child} depth={depth + 1} />
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
