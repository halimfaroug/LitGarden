// Academic Course Data
// Subject: Environmental Science & Sustainability

export type Question = {
  id: string;
  type: 'multiple-choice' | 'true-false' | 'matching' | 'short-answer';
  question: string;
  options?: string[]; // For MC
  pairs?: { term: string; definition: string }[]; // For Matching
  correctAnswer: string | { [key: string]: string }; // string for simple, object for matching
  explanation: string;
};

export type Flashcard = {
  id: string;
  term: string;
  definition: string;
  category: 'core' | 'advanced' | 'case-study';
};

export type MindMapNode = {
  id: string;
  label: string;
  children?: MindMapNode[];
  details?: string;
  linkId?: string; // Links to a flashcard or lesson
};

export const QUIZZES: Question[] = [
  // 1-10: Ecosystems
  {
    id: 'q1',
    type: 'multiple-choice',
    question: 'Which of the following best defines an ecosystem?',
    options: [
      'A community of living organisms interacting with their physical environment',
      'A group of animals living in the same area',
      'The physical features of a landscape',
      'A climate zone with specific weather patterns'
    ],
    correctAnswer: 'A community of living organisms interacting with their physical environment',
    explanation: 'An ecosystem encompasses both the biotic (living) and abiotic (non-living) components interacting as a system.'
  },
  {
    id: 'q2',
    type: 'true-false',
    question: 'Energy flows through an ecosystem in a one-way stream, from primary producers to various consumers.',
    correctAnswer: 'True',
    explanation: 'Energy enters as sunlight, is converted by producers, and flows to consumers, eventually being lost as heat. It does not cycle like matter.'
  },
  // ... adding more representative data for the mockup
  {
    id: 'q3',
    type: 'short-answer',
    question: 'What is the term for the maximum population size of a species that a specific environment can sustain?',
    correctAnswer: 'Carrying capacity',
    explanation: 'Carrying capacity (K) is the limit imposed by environmental resources such as food, habitat, water, and other necessities.'
  },
  {
    id: 'q4',
    type: 'multiple-choice',
    question: 'Which biogeochemical cycle does not have a significant atmospheric component?',
    options: ['Carbon Cycle', 'Nitrogen Cycle', 'Phosphorus Cycle', 'Water Cycle'],
    correctAnswer: 'Phosphorus Cycle',
    explanation: 'Phosphorus cycles primarily through soil, rock, and water, unlike carbon, nitrogen, and water which have large atmospheric reservoirs.'
  },
  {
    id: 'q5',
    type: 'matching',
    question: 'Match the trophic level to its description.',
    pairs: [
      { term: 'Producer', definition: 'Organisms that make their own food' },
      { term: 'Primary Consumer', definition: 'Herbivores that eat producers' },
      { term: 'Secondary Consumer', definition: 'Carnivores that eat herbivores' },
      { term: 'Decomposer', definition: 'Breaks down dead organic matter' }
    ],
    correctAnswer: {
      'Producer': 'Organisms that make their own food',
      'Primary Consumer': 'Herbivores that eat producers',
      'Secondary Consumer': 'Carnivores that eat herbivores',
      'Decomposer': 'Breaks down dead organic matter'
    },
    explanation: 'Trophic levels categorize organisms based on their feeding position in a food chain.'
  }
];

// Generating 50 flashcards (sample subset here for brevity, but I'll create a generator or list enough for UI)
export const FLASHCARDS: Flashcard[] = [
  { id: 'f1', term: 'Sustainability', definition: 'Meeting the needs of the present without compromising the ability of future generations to meet their own needs.', category: 'core' },
  { id: 'f2', term: 'Biodiversity', definition: 'The variety of life in the world or in a particular habitat or ecosystem.', category: 'core' },
  { id: 'f3', term: 'Ecological Footprint', definition: 'The impact of a person or community on the environment, expressed as the amount of land required to sustain their use of natural resources.', category: 'core' },
  { id: 'f4', term: 'Greenhouse Effect', definition: 'The trapping of the sun\'s warmth in a planet\'s lower atmosphere due to the greater transparency of the atmosphere to visible radiation from the sun than to infrared radiation emitted from the planet\'s surface.', category: 'core' },
  { id: 'f5', term: 'Renewable Energy', definition: 'Energy from a source that is not depleted when used, such as wind or solar power.', category: 'core' },
  { id: 'f6', term: 'Keystone Species', definition: 'A species on which other species in an ecosystem largely depend, such that if it were removed the ecosystem would change drastically.', category: 'advanced' },
  { id: 'f7', term: 'Eutrophication', definition: 'Excessive richness of nutrients in a lake or other body of water, frequently due to runoff from the land, which causes a dense growth of plant life and death of animal life from lack of oxygen.', category: 'advanced' },
  { id: 'f8', term: 'Biomagnification', definition: 'The concentration of toxins in an organism as a result of its ingesting other plants or animals in which the toxins are more widely disbursed.', category: 'advanced' },
];

export const MINDMAP_DATA: MindMapNode = {
  id: 'root',
  label: 'Environmental Science',
  details: 'The study of the interaction of the physical, chemical, and biological components of the environment.',
  children: [
    {
      id: 'm1',
      label: 'Ecosystems',
      children: [
        { id: 'm1-1', label: 'Biotic Factors', details: 'Living components (Plants, Animals, Bacteria)' },
        { id: 'm1-2', label: 'Abiotic Factors', details: 'Non-living components (Water, Soil, Air, Sunlight)' },
        { id: 'm1-3', label: 'Energy Flow', details: 'Food Chains, Food Webs, Trophic Levels' }
      ]
    },
    {
      id: 'm2',
      label: 'Biodiversity',
      children: [
        { id: 'm2-1', label: 'Genetic Diversity' },
        { id: 'm2-2', label: 'Species Diversity' },
        { id: 'm2-3', label: 'Ecosystem Diversity' }
      ]
    },
    {
      id: 'm3',
      label: 'Climate Change',
      children: [
        { id: 'm3-1', label: 'Causes', details: 'Greenhouse Gases, Deforestation, Burning Fossil Fuels' },
        { id: 'm3-2', label: 'Impacts', details: 'Sea Level Rise, Extreme Weather, Habitat Loss' },
        { id: 'm3-3', label: 'Mitigation', details: 'Renewable Energy, Carbon Sequestration, Policy' }
      ]
    }
  ]
};

export const PROGRESS_KEYS = {
  KNOWN: 'zen_known',
  REVIEW: 'zen_review',
  MASTERED: 'zen_mastered'
};
